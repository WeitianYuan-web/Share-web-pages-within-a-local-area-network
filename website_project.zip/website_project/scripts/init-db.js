const mysql = require('mysql2/promise');
require('dotenv').config();

async function initDatabase() {
  const connection = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || 'password',
  });

  await connection.query(`CREATE DATABASE IF NOT EXISTS ${process.env.DB_NAME || 'website_project'}`);
  await connection.query(`USE ${process.env.DB_NAME || 'website_project'}`);

  await connection.query(`
    CREATE TABLE IF NOT EXISTS data (
      id INT AUTO_INCREMENT PRIMARY KEY,
      data TEXT NOT NULL,
      ip VARCHAR(45) NOT NULL,
      username VARCHAR(50) NOT NULL,
      color VARCHAR(20) NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `);

  console.log('Database initialized successfully');
  await connection.end();
}

initDatabase().catch(err => {
  console.error('Error initializing database:', err);
  process.exit(1);
});