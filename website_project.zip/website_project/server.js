const express = require('express');
const mysql = require('mysql2/promise');
require('dotenv').config();

const app = express();
app.use(express.json());
app.use(express.static('public'));

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

// 创建数据库连接池
const db = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || 'password',
  database: process.env.DB_NAME || 'website_project',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// 获取客户端IP地址
function getClientIp(req) {
  return req.headers['x-forwarded-for'] || req.socket.remoteAddress;
}

// 保存数据
app.post('/api/data', async (req, res) => {
  try {
    const { data, username, color } = req.body;
    const clientIp = getClientIp(req);
    const query = 'INSERT INTO data (data, ip, username, color) VALUES (?, ?, ?, ?)';
    const [results] = await db.execute(query, [data, clientIp, username, color]);
    res.json({ message: '数据保存成功', id: results.insertId });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: '保存数据时出错' });
  }
});

// 获取历史记录
app.get('/api/history', async (req, res) => {
    try {
        let query = 'SELECT * FROM data';
        const params = [];
        
        // 处理搜索条件
        if (req.query.search) {
            query += ' WHERE data LIKE ? OR username LIKE ? OR color = ?';
            const searchTerm = `%${req.query.search}%`;
            params.push(searchTerm, searchTerm, req.query.search);
        }
        
        query += ' ORDER BY created_at DESC';
        const [results] = await db.execute(query, params);
        res.json(results);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: '获取历史记录时出错' });
    }
});

// 删除历史记录
app.delete('/api/history', async (req, res) => {
    try {
        const { ids } = req.body;
        if (!ids || !Array.isArray(ids) || ids.length === 0) {
            return res.status(400).json({ message: '无效的请求' });
        }

        const placeholders = ids.map(() => '?').join(',');
        const query = `DELETE FROM data WHERE id IN (${placeholders})`;
        const [results] = await db.execute(query, ids);
        res.json({ message: '删除成功', deletedCount: results.affectedRows });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: '删除历史记录时出错' });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`服务器已启动，端口：${PORT}`);
});