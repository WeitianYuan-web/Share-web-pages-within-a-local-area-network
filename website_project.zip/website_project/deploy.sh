#!/bin/bash

# 1. 安装必要软件
sudo apt update
sudo apt install -y nodejs npm mysql-server

# 2. 配置MySQL
sudo mysql -e "CREATE DATABASE website_project;"
sudo mysql -e "CREATE USER 'root'@'localhost' IDENTIFIED BY 'your_password';"
sudo mysql -e "GRANT ALL PRIVILEGES ON website_project.* TO 'root'@'localhost';"
sudo mysql -e "FLUSH PRIVILEGES;"

# 3. 复制项目文件
# 假设项目文件已上传到服务器
cd /path/to/project

# 4. 安装项目依赖
npm install

# 5. 初始化数据库
npm run init-db

# 6. 设置环境变量
echo "DB_HOST=localhost" > .env
echo "DB_USER=root" >> .env
echo "DB_PASSWORD=your_password" >> .env
echo "DB_NAME=website_project" >> .env
echo "PORT=3001" >> .env

# 7. 启动项目
npm start

#已创建部署脚本deploy.sh，以下是部署步骤：

#在目标Ubuntu服务器上执行以下命令：

#上传项目文件到服务器
#给部署脚本执行权限：chmod +x deploy.sh
#运行部署脚本：./deploy.sh
#部署脚本将自动完成以下操作：

#安装Node.js、npm和MySQL
#配置MySQL数据库
#安装项目依赖
#初始化数据库
#设置环境变量
#启动项目
#项目启动后，可通过服务器IP:3001访问

#注意：请根据实际情况修改部署脚本中的数据库密码和项目路径